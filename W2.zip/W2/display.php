<?php
    foreach($_SESSION['var'] as $key => $value){
        echo "$key: $value<br>";
    }

?>